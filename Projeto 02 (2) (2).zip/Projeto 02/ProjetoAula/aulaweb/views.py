# aulaweb/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView, LogoutView
from .models import Usuario, Evento, Inscricao
from .forms import UsuarioCreationForm, LoginForm, EventoForm


# ========== AUTENTICAÇÃO ==========

def cadastro_usuario(request):
    """Cria um novo usuário e faz login automático."""
    if request.method == 'POST':
        form = UsuarioCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Cadastro realizado com sucesso!")
            return redirect('index')
    else:
        form = UsuarioCreationForm()
    return render(request, 'aulaweb/cadastro_usuario.html', {'form': form})


class CustomLoginView(LoginView):
    """Tela de login personalizada."""
    template_name = 'aulaweb/login.html'
    authentication_form = LoginForm


class CustomLogoutView(LogoutView):
    """Logout com redirecionamento automático para a página inicial."""
    next_page = '/'


# ========== PÁGINAS PRINCIPAIS ==========

def index(request):
    """
    Página inicial do site.
    Mostra todos os eventos existentes, ranqueados pelo número de inscrições.
    """
    eventos = Evento.objects.all()

    # Criamos uma lista com evento e quantidade de inscritos
    eventos_info = []
    for evento in eventos:
        inscritos = Inscricao.objects.filter(evento=evento).count()
        eventos_info.append({
            'evento': evento,
            'inscritos': inscritos
        })

    # Ordena decrescentemente pelo número de inscritos
    eventos_info.sort(key=lambda x: x['inscritos'], reverse=True)

    return render(request, 'aulaweb/index.html', {
        'eventos_info': eventos_info
    })

def sobre(request):
    """Página 'Sobre' institucional."""
    return render(request, 'aulaweb/sobre.html')


# ========== EVENTOS ==========

@login_required
def lista_eventos(request):
    """Lista todos os eventos disponíveis."""
    eventos = Evento.objects.all().order_by('data_inicio')
    return render(request, 'aulaweb/lista_eventos.html', {'eventos': eventos})


@login_required
def detalhe_evento(request, evento_id):
    """Exibe os detalhes de um evento específico."""
    evento = get_object_or_404(Evento, id=evento_id)
    ja_inscrito = Inscricao.objects.filter(usuario=request.user, evento=evento).exists()
    return render(request, 'aulaweb/detalhe_evento.html', {
        'evento': evento,
        'ja_inscrito': ja_inscrito
    })


@login_required
def cadastro_evento(request):
    """Permite que um organizador cadastre um novo evento."""
    if request.user.perfil != 'organizador':
        messages.error(request, "Apenas organizadores podem cadastrar eventos.")
        return redirect('lista_eventos')

    if request.method == 'POST':
        form = EventoForm(request.POST)
        if form.is_valid():
            evento = form.save(commit=False)
            evento.organizador = request.user
            evento.save()
            messages.success(request, "Evento cadastrado com sucesso!")
            return redirect('lista_eventos')
    else:
        form = EventoForm()

    return render(request, 'aulaweb/cadastro_evento.html', {'form': form})


@login_required
def deletar_evento(request, evento_id):
    """Permite que o organizador exclua um evento."""
    evento = get_object_or_404(Evento, id=evento_id)

    if evento.organizador != request.user:
        messages.error(request, "Você não tem permissão para excluir este evento.")
        return redirect('detalhe_evento', evento_id=evento.id)

    if request.method == "POST":
        evento.delete()
        messages.success(request, "Evento excluído com sucesso!")
        return redirect('lista_eventos')

    return render(request, 'aulaweb/confirmar_exclusao.html', {'evento': evento})


# ========== INSCRIÇÕES ==========

@login_required
def inscrever_evento(request, evento_id):
    """Realiza a inscrição do usuário em um evento."""
    evento = get_object_or_404(Evento, id=evento_id)

    total = Inscricao.objects.filter(evento=evento).count()
    if evento.max_participantes and total >= evento.max_participantes:
        messages.error(request, "Evento cheio. Não é possível se inscrever.")
        return redirect('detalhe_evento', evento_id=evento.id)

    inscricao, created = Inscricao.objects.get_or_create(usuario=request.user, evento=evento)
    if created:
        messages.success(request, f"Inscrição realizada em {evento.nome}!")
    else:
        messages.info(request, "Você já está inscrito neste evento.")

    return redirect('minhas_inscricoes')


@login_required
def minhas_inscricoes(request):
    """Lista todas as inscrições do usuário logado."""
    inscricoes = Inscricao.objects.filter(usuario=request.user).select_related('evento')
    return render(request, 'aulaweb/minhas_inscricoes.html', {'inscricoes': inscricoes})


# ========== CERTIFICADOS ==========

@login_required
def certificado_view(request, inscricao_id):
    """Exibe (ou simula) a emissão de certificado."""
    inscricao = get_object_or_404(Inscricao, id=inscricao_id)

    if inscricao.usuario != request.user and inscricao.evento.organizador != request.user:
        messages.error(request, "Você não tem permissão para visualizar este certificado.")
        return redirect('index')

    if not inscricao.certificado_emitido:
        inscricao.certificado_emitido = True
        inscricao.save()
        messages.success(request, "Certificado emitido com sucesso (simulação).")

    return render(request, 'aulaweb/certificado_preview.html', {'inscricao': inscricao})


from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Evento, Inscricao

@login_required
def meus_eventos(request):
    """
    Exibe os eventos criados pelo usuário logado.
    Mostra detalhes de cada evento e quantidade de inscritos.
    """
    # Eventos do organizador logado
    eventos = Evento.objects.filter(organizador=request.user)
    
    # Lista com info de cada evento
    eventos_info = []
    for evento in eventos:
        inscritos = Inscricao.objects.filter(evento=evento).count()
        eventos_info.append({
            'evento': evento,
            'inscritos': inscritos
        })
    
    # Renderiza o template com as informações
    return render(request, 'aulaweb/meus_eventos.html', {
        'eventos_info': eventos_info
    })


# aulaweb/views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm

def login_usuario(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"Bem-vindo, {username}!")
                return redirect('index')  # redireciona para a página inicial
            else:
                messages.error(request, "Usuário ou senha inválidos.")
        else:
            messages.error(request, "Erro ao autenticar. Verifique os dados.")
    else:
        form = AuthenticationForm()
    return render(request, 'aulaweb/login.html', {'form': form})


def logout_usuario(request):
    logout(request)
    messages.info(request, "Você saiu da sua conta.")
    return redirect('login_usuario')


from django.contrib.auth.decorators import login_required

@login_required(login_url='login_usuario')
def meus_eventos(request):
    # código da view
    ...

from django.http import JsonResponse

def api(request):
    return JsonResponse({"mensagem": "API funcionando!"})
