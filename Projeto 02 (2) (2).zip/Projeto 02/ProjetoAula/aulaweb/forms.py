from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import Usuario, Evento, Inscricao

class UsuarioCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    instituicao = forms.CharField(required=False)

    class Meta:
        model = Usuario
        fields = ("username", "email", "telefone", "instituicao", "perfil", "password1", "password2")


class LoginForm(AuthenticationForm):
    username = forms.CharField(label="Usuário")
    password = forms.CharField(label="Senha", widget=forms.PasswordInput)


from django import forms
from .models import Evento

from django import forms
from .models import Evento

class EventoForm(forms.ModelForm):
    class Meta:
        model = Evento
        fields = [
            'nome',
            'tipo',
            'data_inicio',
            'data_fim',
            'horario',
            'local',
            'max_participantes',
            'organizador',
        ]



class InscricaoForm(forms.ModelForm):
    class Meta:
        model = Inscricao
        fields = []  # nada a preencher: a inscrição será criada no backend vinculando evento + usuário


# aulaweb/forms.py
from django import forms
from django.contrib.auth.forms import AuthenticationForm

class LoginForm(AuthenticationForm):
    username = forms.CharField(label="Usuário", widget=forms.TextInput(attrs={'class': 'form-control'}))
    password = forms.CharField(label="Senha", widget=forms.PasswordInput(attrs={'class': 'form-control'}))
